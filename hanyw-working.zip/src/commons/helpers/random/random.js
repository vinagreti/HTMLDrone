"use strict";
exports.__esModule = true;
exports.randomFromZero = function (n) {
    return Math.floor((Math.random() * n));
};
exports.chooseOneRandomly = function (a, b) {
    return exports.randomFromZero(10) > 5 ? a : b;
};
