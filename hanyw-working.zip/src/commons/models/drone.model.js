"use strict";
exports.__esModule = true;
var random_1 = require("./../helpers/random/random");
// x, y are coords
// (values sent as strings, but must be treated as floating point number)
var Drone = /** @class */ (function () {
    function Drone(data) {
        if (data === void 0) { data = {}; }
        this.id = data.id;
        this.quadrant = data.quadrant;
        this.positionX = parseFloat(data.positionX || random_1.randomFromZero(1000));
        this.positionY = parseFloat(data.positionY || random_1.randomFromZero(1000));
    }
    return Drone;
}());
exports.Drone = Drone;
