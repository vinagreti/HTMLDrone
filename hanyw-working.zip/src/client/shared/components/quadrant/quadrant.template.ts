export const template = `
  <div id="quadrant-wrapper"></div>
`;