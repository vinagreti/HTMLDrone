export const template = `
  <div id="drone-wrapper">*</div>
`;
