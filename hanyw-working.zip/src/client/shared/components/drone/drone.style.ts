export const style = `
  #drone-wrapper {
    position: fixed;
    color: white;
  }
`;
