import { MainServer } from './main';

(() => {
  console.log('running main server');
  new MainServer();
})();
